const startButton = document.getElementById("start-button");
const hitButton = document.getElementById("hit-button");
const standButton = document.getElementById("stand-button");
const splitButton = document.getElementById("split-button");
const playerBalanceSpan = document.getElementById("player-balance");
const betAmountInput = document.getElementById("bet-amount");
const playerHand = document.querySelector(".player-hand");
const dealerHand = document.querySelector(".dealer-hand");

let playerBalance = 1000;
let betAmount = 0;
let playerHandCards = [];
let dealerHandCards = [];

// Variable para controlar si el juego ha terminado
let gameOver = false;

// Función para iniciar el juego
function startGame() {
    // Reiniciar
    playerHandCards = [];
    dealerHandCards = [];
    playerHand.innerHTML = "";
    dealerHand.innerHTML = "";

    // Apostar
    betAmount = parseInt(betAmountInput.value);
    if (betAmount > playerBalance) {
        alert("No tienes suficiente saldo para esa apuesta.");
        return;
    }

    // Iniciar juego
    playerBalance -= betAmount;
    updateBalance(0);

    // Repartir cartas iniciales
    dealInitialCards();

    // Habilitar botones
    startButton.disabled = true;
    hitButton.disabled = false;
    standButton.disabled = false;
    splitButton.disabled = false;
    gameOver = false;
}

// Función para repartir cartas iniciales
function dealInitialCards() {
    playerHandCards.push(getRandomCard());
    dealerHandCards.push(getRandomCard());
    playerHandCards.push(getRandomCard());
    dealerHandCards.push(getRandomCard());

    showCards(playerHandCards, playerHand);
    showCards([dealerHandCards[0], "?"], dealerHand);
}
// Función para finalizar el juego
function endGame(message) {
    disableButtons();
    revealDealerHand();
    updateUI();
    
    const resultsContainer = document.querySelector(".results");
    const playerResultElement = document.getElementById("player-result");
    const dealerResultElement = document.getElementById("dealer-result");
    
    resultsContainer.classList.remove("hidden");

    const playerResult = calculateHandValue(playerHandCards);
    const dealerResult = calculateHandValue(dealerHandCards);

    playerResultElement.textContent = `Resultado del Jugador: ${playerResult}`;
    dealerResultElement.textContent = `Resultado del Crupier: ${dealerResult}`;

    const choice = confirm(message + " ¿Deseas continuar?");
    
    if (choice) {
        // Reiniciar el juego
        resetGame();
    } else {
        // Reiniciar la página
        location.reload();
    }
}


// Función para reiniciar el juego
function resetGame() {
    playerHandCards = [];
    dealerHandCards = [];
    playerHand.innerHTML = "";
    dealerHand.innerHTML = "";
    playerBalanceSpan.textContent = `$${playerBalance}`;
    betAmountInput.value = "";
    startButton.disabled = false;
}

// Función para obtener una carta aleatoria
function getRandomCard() {
    const cards = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    const randomIndex = Math.floor(Math.random() * cards.length);
    return cards[randomIndex];
}

// Función para mostrar las cartas
function showCards(cards, element) {
    const cardsContainer = document.createElement("div");
    cardsContainer.classList.add("hand");

    for (const card of cards) {
        const cardElement = document.createElement("div");
        cardElement.classList.add("card");
        cardElement.textContent = card;
        cardsContainer.insertBefore(cardElement, cardsContainer.firstChild);
    }

    element.innerHTML = "";
    element.appendChild(cardsContainer);
}

// Función para actualizar el saldo del jugador
function updateBalance(amount) {
    playerBalance += amount;
    playerBalanceSpan.textContent = `$${playerBalance}`;
}

// Función para calcular el valor total de una mano
function calculateHandValue(hand) {
    let value = 0;
    let aceCount = 0;

    for (const card of hand) {
        if (card === "A") {
            value += 11;
            aceCount++;
        } else if (card === "K" || card === "Q" || card === "J") {
            value += 10;
        } else {
            value += parseInt(card);
        }
    }

    while (value > 21 && aceCount > 0) {
        value -= 10;
        aceCount--;
    }

    return value;
}

// Función para verificar si una mano tiene Blackjack
function hasBlackjack(hand) {
    return hand.length === 2 && calculateHandValue(hand) === 21;
}

// Función para pedir una carta
function hit() {
    playerHandCards.push(getRandomCard());
    showCards(playerHandCards, playerHand);

    const playerHandValue = calculateHandValue(playerHandCards);
    if (playerHandValue > 21) {
        endGame("¡Te has pasado de 21! Has perdido.");
    } else if (playerHandValue === 21) {
        stand();
    }
}

// Función para plantarse
function stand() {
    disableButtons();
    // ...
    revealDealerHand();
    // ...
    endGame(determineWinner());
}



// Función para determinar el ganador
function determineWinner() {
    const playerHandValue = calculateHandValue(playerHandCards);
    const dealerHandValue = calculateHandValue(dealerHandCards);

    if (playerHandValue > 21) {
        return "¡Te has pasado de 21! Has perdido.";
    } else if (dealerHandValue > 21) {
        updateBalance(betAmount * 2);
        return "¡El crupier se ha pasado de 21! Has ganado.";
    } else if (playerHandValue > dealerHandValue) {
        updateBalance(betAmount * 2);
        return "¡Has ganado!";
    } else if (playerHandValue < dealerHandValue) {
        return "El crupier ha ganado.";
    } else {
        updateBalance(betAmount);
        return "Empate.";
    }
}


// Función para deshabilitar botones durante el juego
function disableButtons() {
    hitButton.disabled = true;
    standButton.disabled = true;
    splitButton.disabled = true;
}
// Función para dividir cartas
function split() {
    if (playerHandCards.length === 2 && playerHandCards[0] === playerHandCards[1]) {
        // Verificar si el jugador tiene dos cartas iguales para dividir
        const newHand1 = [playerHandCards[0], getRandomCard()];
        const newHand2 = [playerHandCards[1], getRandomCard()];

        // Actualizar la mano del jugador con las manos divididas
        playerHandCards = newHand1;

        // Agregar la segunda mano a la UI
        const newHandDiv = document.createElement("div");
        newHandDiv.classList.add("hand");
        showCards(newHand2, newHandDiv);
        playerHand.appendChild(newHandDiv);

        // Deshabilitar el botón de dividir después de dividir una vez
        splitButton.disabled = true;
    } else {
        alert("No puedes dividir en este momento.");
    }
}

// Función para deshabilitar botones durante el juego
function disableButtons() {
    hitButton.disabled = true;
    standButton.disabled = true;
    // splitButton.disabled = true;
}

// Función para actualizar la interfaz con las manos y la puntuación
function updateUI() {
    showCards(playerHandCards, playerHand);
    showCards(dealerHandCards, dealerHand);

    const playerHandValue = calculateHandValue(playerHandCards);
    const dealerHandValue = calculateHandValue(dealerHandCards);

    // Actualizar interfaz con las puntuaciones
    // ...
}
// Función para revelar todas las cartas del crupier
function revealDealerHand() {
    dealerHand.innerHTML = "";

    // Mostrar todas las cartas del crupier
    showCards(dealerHandCards, dealerHand);
}

// Agregar eventos a los botones
startButton.addEventListener("click", startGame);
hitButton.addEventListener("click", hit);
standButton.addEventListener("click", stand);
splitButton.addEventListener("click", split);
